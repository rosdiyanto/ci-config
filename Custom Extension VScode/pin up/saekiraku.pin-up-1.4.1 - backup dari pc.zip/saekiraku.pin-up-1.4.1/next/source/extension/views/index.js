import vscode from "vscode";

import initTreeview from "./treeview";

export default function () {
    initTreeview()
}
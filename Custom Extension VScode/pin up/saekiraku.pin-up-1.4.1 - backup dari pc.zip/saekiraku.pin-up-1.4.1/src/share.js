/**
 * This module share data and objects between modules.
 */

module.exports = {};